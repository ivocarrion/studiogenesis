<?php

namespace Database\Seeders;

use App\Models\Categoria;
use Illuminate\Database\Seeder;

class CategoriaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $categorias = factory('\App\Models\Categoria',1)->create();
        \App\Models\Categoria::factory()->times(1)->create();
    }
}
