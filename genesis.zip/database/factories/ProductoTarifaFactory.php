<?php

namespace Database\Factories;

use App\Models\ProductoTarifa;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductoTarifaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ProductoTarifa::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
