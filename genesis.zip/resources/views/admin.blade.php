@extends('admin.layout')

@section('content')
<h1>Bienvenidos al panel de administación de StudioGénesis</h1>
<p class="lead">Podrás gestionar categorías y productos desde el menú a tu izquierda.</p>
<p class="lead italic">¡Que lo disfrutes!</p>
@endsection
