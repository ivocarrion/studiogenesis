<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-sm-12">
    <div class="card">
        <form class="form-horizontal" method="POST" action="<?php echo e(route('productos.store')); ?>" role="form" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body row">
                <h4 class="card-title">Ver Producto </h4>
                <div class="col-sm-6">
                    <div class="form-group row">
                        <label class="col-sm-4 text-end control-label col-form-label">Nombre Prod</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nombre_prod"
                                placeholder=" "  >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 text-end control-label col-form-label">Imagen Principal (min 200px * 200px)</label><br/>
                        <div class="col-sm-8">
                        <input  class="form-control bg-light shadow-sm  border-0" type="file" name="foto_prod" value="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label
                            class="col-sm-4 text-end control-label col-form-label">Descripción Prod</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="descripcion_prod"
                                placeholder=" "  >
                        </div>
                    </div>

                <?php echo $__env->make('productos._form-categorias', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





            </div>
                <?php echo $__env->make('productos._form-galeria', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        </form>
        <div class="border-top">
            <div class="card-body">
               <button type="submit" class="btn btn-info">Guardar</button>
                
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!--deccion dcha-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\genesis\resources\views/productos/create.blade.php ENDPATH**/ ?>