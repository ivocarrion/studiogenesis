<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <h4 class="card-title">Categorías</h4>
        <a class=" justify-content-between btn button btn-primary" href="<?php echo e(route('categorias.create')); ?>">Crear Categoría</a>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Categoria ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Descripción</th>
                <th scope="col">Categoría Padre</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <td scope="row"><?php echo e($categoria->id); ?></td>
                <td><?php echo e($categoria->nombre_cat); ?></td>
                <td><?php echo e($categoria->descripcion_cat); ?></td>
                <?php if(isset($categoria->padre->nombre_cat)): ?>
                <td> <?php echo e($categoria->padre->nombre_cat); ?> </td>
                <?php else: ?>
                <td>   </td>
                <?php endif; ?>
                <td> <a class=" justify-content-between" href="<?php echo e(route('categorias.show', $categoria)); ?>">Ver</a> | <a class="  justify-content-between" href="<?php echo e(route('categorias.edit', $categoria)); ?>">Editar</a></td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <td colspan="4">No hay productos</li>

        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\genesis\resources\views/categorias/index.blade.php ENDPATH**/ ?>