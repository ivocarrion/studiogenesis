<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-sm-12">
    <div class="card">
        <form class="form-horizontal">
            <div class="card-body row">
                <h4 class="card-title">Ver Producto </h4>
                <div class="col-sm-6">
                    <div class="form-group row">
                    <label
                        class="col-sm-4 text-end control-label col-form-label">Producto Id</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control"
                            placeholder="<?php echo e($producto->id); ?>" disabled>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 text-end control-label col-form-label">Imagen destacada</label>
                    <div class="col-sm-8">
                        <img src="<?php echo e(Storage::url($producto->foto_prod)); ?>" name="<?php echo e($producto->nombre_prod); ?>" class="img-fluid" style="max-width: 200px">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 text-end control-label col-form-label">Nombre Prod</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control"
                            placeholder="<?php echo e(old('producto', $producto->nombre_prod)); ?>" >
                    </div>
                </div>
                <div class="form-group row">
                    <label
                        class="col-sm-4 text-end control-label col-form-label">Descripción Prod</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control"
                            placeholder="<?php echo e(old('descripcion_prod', $producto->descripcion_prod)); ?>" >
                    </div>
                </div>

                <div class="form-group row">
                    <label
                        class="col-sm-4 text-end control-label col-form-label">Categorías actuales</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control"   placeholder="

                            <?php $__currentLoopData = $producto->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($categoria->nombre_cat); ?> | <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" disbled>

                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 mt-3">Selecciona Categorías</label>
                    <div class="col-md-9">
                        <select class="select2 select2-container select2-container--default select2-container--below select2-container--focus select2-container--open" multiple="multiple"
                            style="width: 100%;" name="categoria[]">
                            <optgroup label="Categorías">

                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre_cat); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </optgroup>


                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label
                    class="col-sm-12  control-label col-form-label">Tarifas</label>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Fecha Inicio</th>
                                <th scope="col">Fecha Fin</th>
                                <th scope="col">Precio</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $producto->tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>

                                    <td><?php echo e($tarifa->fecha_ini); ?></td>
                                    <td><?php echo e($tarifa->fecha_fin); ?></td>
                                    <td><?php echo e($tarifa->precio); ?></td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <td colspan="3">No hay tarifas creadas.  <a href="<?php echo e(route('productotarifa.create')); ?>" class="btn btn-primary">Crear tarifas</a></li>

                            <?php endif; ?>

                        </tbody>

                    </table>
                </div>


            </div>
               <div class="col-sm-6">
    <label    class="col-sm-12  control-label col-form-label">Galería imágenes</label>
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->




</div>

        </form>

        <!-- Galeria de imagenes -->+


        <div class="form-group">
            <label for="img" class="negrita">Selecciona una imagen:</label>
            <div>
                <input name="foto_galeria[]" type="file" id="img" multiple="multiple">
                <br>
                <br>

                <?php if( !empty ( $producto->galeria) ): ?>

                  <span>Imagen(es) Actual(es): </span>

                  <br>

                  <!-- Mensaje: Imagen Eliminada Satisfactoriamente ! -->
                  <?php if(Session::has('message')): ?>
                    <div class="alert alert-primary" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                  <?php endif; ?>

                  <!-- Mostramos todas las imágenes pertenecientesa a este registro -->

                  <?php $__currentLoopData = $producto->galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <img src=" <?php echo e(Storage::url($img->foto_galeria)); ?>" width="200" class="img-fluid">

                  <!-- Botón para Eliminar la Imagen individualmente -->
                  <a href="<?php echo e(route('galeriaproductos', $img->id )); ?>" class="btn btn-danger btn-sm" onclick="return confirmarEliminar();">Eliminar</a>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <script type="text/javascript">

                    function confirmarEliminar() {
                        var x = confirm("Estas seguro de Eliminar?");
                        if (x)
                            return true;
                        else
                            return false;
                    }

                </script>

               <?php else: ?>

               Aún no se ha cargado una imagen para este producto <?php endif; ?>

            </div>

        </div>

        <!-- *** galeria de imagenes ****-->
        <div class="border-top">
            <div class="card-body">
                
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!--deccion dcha-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\genesis\resources\views/productos/edit.blade.php ENDPATH**/ ?>