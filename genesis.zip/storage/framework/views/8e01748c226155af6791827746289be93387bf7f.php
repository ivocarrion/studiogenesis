<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <h4 class="card-title mb-0">Productos</h4>
        <a class=" justify-content-between btn button btn-primary" href="<?php echo e(route('productos.create')); ?>">Crear Producto</a>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Producto ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Descripción</th>
                <th scope="col">Categorías</th>
                <th scope="col">Tarifas</th>
                <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <td scope="row"><?php echo e($producto->id); ?></td>
                <td><?php echo e($producto->nombre_prod); ?></td>
                <td><?php echo e($producto->descripcion_prod); ?></td>
                <td><?php $__currentLoopData = $producto->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($categoria->nombre_cat); ?> |
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php $__currentLoopData = $producto->tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($tarifa->fecha_ini); ?> a <?php echo e($tarifa->fecha_fin); ?>=<?php echo e($tarifa->precio); ?> <br/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td> <a class=" justify-content-between" href="<?php echo e(route('productos.show', $producto)); ?>">Ver</a></td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <td colspan="4">No hay productos</li>

        <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($productos->links()); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\genesis\resources\views/productos/index.blade.php ENDPATH**/ ?>