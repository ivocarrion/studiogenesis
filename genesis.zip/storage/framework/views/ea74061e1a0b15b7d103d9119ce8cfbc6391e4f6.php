<div class="form-group row">
    <label
    class="col-sm-12  control-label col-form-label">Tarifas</label>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Fecha Inicio</th>
                <th scope="col">Fecha Fin</th>
                <th scope="col">Precio</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $producto->tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>


                    <td><?php echo e($tarifa->fecha_ini); ?></td>
                    <td><?php echo e($tarifa->fecha_fin); ?></td>
                    <td><?php echo e($tarifa->precio); ?></td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <td colspan="3">No hay productos</li>

            <?php endif; ?>

        </tbody>

    </table>
</div>
<?php /**PATH C:\laragon\www\genesis\resources\views/productos/_form-tarifas.blade.php ENDPATH**/ ?>