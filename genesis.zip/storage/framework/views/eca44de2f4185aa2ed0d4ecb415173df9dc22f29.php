<div class="form-group row">
    <label class="col-md-3 mt-3">Multiple Select</label>
    <div class="col-md-9">
        <select class="select2 select2-container select2-container--default select2-container--below select2-container--focus select2-container--open" multiple="multiple"
            style="width: 100%;" name="categoria[]">
            <optgroup label="Categorías">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre_cat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </optgroup>


        </select>
    </div>
</div>

<?php /**PATH C:\laragon\www\genesis\resources\views/productos/_form-categorias.blade.php ENDPATH**/ ?>