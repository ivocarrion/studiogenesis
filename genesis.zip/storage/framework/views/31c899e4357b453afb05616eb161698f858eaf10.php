<?php $__env->startSection('content'); ?>
<h1>Bienvenidos al panel de administación de StudioGénesis</h1>
<p class="lead">Podrás gestionar categorías y productos desde el menú a tu izquierda.</p>
<p class="lead italic">¡Que lo disfrutes!</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\genesis\resources\views/admin.blade.php ENDPATH**/ ?>