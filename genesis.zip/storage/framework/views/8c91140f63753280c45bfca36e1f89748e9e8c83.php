<div class="col-sm-6">
    <label
    class="col-sm-12  control-label col-form-label">Galería imágenes</label>
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <?php if( !empty ( $producto->id) ): ?>


    <div class="form-group">
        <label for="galeria_prod" class="negrita">Selecciona imágenes:</label>
        <div>
            <input name="galeria_prod[]" type="file" id="galeria_prod" multiple="multiple">
            <br>
            <br>

        </div>

    </div>

  <?php else: ?>



    <div class="form-group">
        <label for="galeria_prod" class="negrita">Selecciona una imagen:</label>
        <div>
            <input name="galeria_prod[]" type="file" id="galeria_prod" multiple="multiple">
        </div>
    </div>

  <?php endif; ?>
</div>





  

  <!-- Botón para Eliminar la Imagen individualmente -->
  




<?php /**PATH C:\laragon\www\genesis\resources\views/productos/_form-galeria.blade.php ENDPATH**/ ?>