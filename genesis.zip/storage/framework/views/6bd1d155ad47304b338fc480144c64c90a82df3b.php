<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-sm-12">
    <div class="card">
        <form class="form-horizontal">
            <div class="card-body row">
                <h4 class="card-title">Ver Producto </h4>
                <div class="col-sm-6">
                    <div class="form-group row">
                    <label
                        class="col-sm-4 text-end control-label col-form-label">Producto Id</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control"
                            placeholder="<?php echo e($producto->id); ?>" disabled>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 text-end control-label col-form-label">Imagen destacada</label>
                        <div class="col-sm-8">
                            <img src="<?php echo e(Storage::url($producto->foto_prod)); ?>" style="max-width:200px" name="<?php echo e($producto->nombre_prod); ?>" class="img-fluid">
                        </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 text-end control-label col-form-label">Nombre Prod</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control"
                            placeholder="<?php echo e($producto->nombre_prod); ?>" disabled>
                    </div>
                </div>
                <div class="form-group row">
                    <label
                        class="col-sm-4 text-end control-label col-form-label">Descripción Prod</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control"
                            placeholder="<?php echo e($producto->descripcion_prod); ?>" disabled>
                    </div>
                </div>

                <div class="form-group row">
                    <label
                        class="col-sm-4 text-end control-label col-form-label">Categorías</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" disabled  placeholder="

                            <?php $__currentLoopData = $producto->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($categoria->nombre_cat); ?> | <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">

                    </div>
                </div>

                <div class="form-group row">
                    <label
                    class="col-sm-12  control-label col-form-label">Tarifas</label>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Fecha Inicio</th>
                                <th scope="col">Fecha Fin</th>
                                <th scope="col">Precio</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $producto->tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>


                                    <td><?php echo e($tarifa->fecha_ini); ?></td>
                                    <td><?php echo e($tarifa->fecha_fin); ?></td>
                                    <td><?php echo e($tarifa->precio); ?></td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <td colspan="3">No hay tarifas creadas.  <a href="<?php echo e(route('productotarifa.create')); ?>" class="btn btn-primary">Crear tarifas</a></li>

                            <?php endif; ?>

                        </tbody>

                    </table>
                </div>


            </div>
               <div class="col-sm-6">
    <label
    class="col-sm-12  control-label col-form-label">Galería imágenes</label>
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <?php if( !empty ( $producto->id) ): ?>


    <div class="form-group">

        <div>


            <?php if( !empty ( $producto->id) ): ?>

              <span>Imagen(es) Actual(es): </span>
              <br>

              <!-- Mensaje: Imagen Eliminada Satisfactoriamente ! -->
              <?php if(Session::has('message')): ?>
              <div class="alert alert-primary" role="alert">
                  <?php echo e(Session::get('message')); ?>

              </div>
              <?php endif; ?>

              <!-- Mostramos todas las imágenes pertenecientesa a este registro -->
              <?php $__currentLoopData = $producto->galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <img src=" <?php echo e(Storage::url($img->foto_galeria)); ?>" width="200" class="img-fluid">

                <!-- Botón para Eliminar la Imagen individualmente -->
                

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

                Aún no se ha cargado una imagen para este producto

            <?php endif; ?>
        </div>

    </div>

  <?php else: ?>



    <div class="form-group">
        <label for="galeria_prod" class="negrita">Selecciona una imagen:</label>
        <div>
            <input name="galeria_prod[]" type="file" id="galeria_prod" multiple="multiple">
        </div>
    </div>

  <?php endif; ?>
</div>




        </form>
        <div class="border-top">
            <div class="card-body">
                <a type="button" href="<?php echo e(route('productos.edit', $producto)); ?>" class="btn btn-info">Editar</a>
                <a class="btn btn-danger" href="#" onclick='event.preventDefault();document.getElementById("delete-producto").submit()'>Eliminar</a>

                
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!--deccion dcha-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\genesis\resources\views/productos/show.blade.php ENDPATH**/ ?>