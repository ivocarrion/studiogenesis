<?php $__env->startSection('content'); ?>

<div class="col-sm-6">
<div class="card">
    <form class="form-horizontal">
        <div class="card-body">
            <h4 class="card-title">Ver Categoría </h4>
            <div class="form-group row">
                <label
                    class="col-sm-3 text-end control-label col-form-label">Categoría Id</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control"
                        placeholder="<?php echo e($categoria->id); ?>" disabled>
                        <span> </span>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-3 text-end control-label col-form-label">Nombre Cat</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control"
                        placeholder="<?php echo e($categoria->nombre_cat); ?>" disabled>
                </div>
            </div>
            <div class="form-group row">
                <label
                    class="col-sm-3 text-end control-label col-form-label">Descripción Cat</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control"
                        placeholder="<?php echo e($categoria->descripcion_cat); ?>" disabled>
                </div>
            </div>
            <div class="form-group row">
                <label
                    class="col-sm-3 text-end control-label col-form-label">Padre Cat</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" disabled

                    <?php if(isset($categoria->padre->nombre_cat)): ?>
                      placeholder="<?php echo e($categoria->padre->nombre_cat); ?>"
                    <?php else: ?>
                     placeholder="Es categoría padre"
                    <?php endif; ?>

                    >

                </div>
            </div>




    </form>
    <div class="border-top">
        <div class="card-body">
            <a type="button" href="<?php echo e(route('categorias.edit', $categoria)); ?>" class="btn btn-info">Editar</a>
            <a class="btn btn-danger" href="#" onclick='event.preventDefault();document.getElementById("delete-categoria").submit()'>Eliminar</a>

            <form class="form-horizontal" id="delete-categoria" method="POST" action=" <?php echo e(route('categorias.destroy', $categoria)); ?>">

                <?php echo csrf_field(); ?>   <?php echo method_field('DELETE'); ?>

            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\genesis\resources\views/categorias/show.blade.php ENDPATH**/ ?>